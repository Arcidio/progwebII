package com.example.appfile

class Contants {
    companion object{
        val ADRRESS_IP = "http://192.168.0.15:8080/"
    }
}
