package com.example.appfile.interfaz

interface Interfaz {
    fun onClick(posicion:Int,nombre:String,id_usuario:String,id_solicitud:String)
}